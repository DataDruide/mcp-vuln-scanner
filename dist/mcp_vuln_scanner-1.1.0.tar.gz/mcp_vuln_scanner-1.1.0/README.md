# MCP Vulnerability Scanner

Security vulnerability scanner for MCP (Model Context Protocol) servers.

## Features

- 🔍 Detect dangerous operations (command injection, path traversal)
- 🎭 Tool poisoning detection (typosquatting, misleading descriptions)
- 📦 CVE database integration
- 📊 Multiple output formats (JSON, HTML, SARIF, console)
- 🌐 Live MCP server scanning
- 🔐 Pro version with advanced features

## Installation

```bash
pip install mcp-vuln-scanner
