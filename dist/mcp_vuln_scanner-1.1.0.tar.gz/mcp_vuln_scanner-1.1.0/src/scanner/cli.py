import click
import json
from pathlib import Path
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scanner.analyzers.dangerous_ops import DangerousOperationAnalyzer, RiskLevel
from scanner.analyzers.tool_poisoning import ToolPoisoningDetector
from scanner.reporters.sarif_reporter import SarifReporter
from scanner.reporters.html_reporter import HtmlReporter
from scanner.ai_fixer import AIFixer
from scanner.notify import send_slack_alert, send_jira_issue

@click.command()
@click.argument("target", required=True)
@click.option("--format", "-f", type=click.Choice(["json", "sarif", "html", "console"]), default="console", help="Ausgabeformat")
@click.option("--output", "-o", type=Path, help="Ausgabedatei")
@click.option("--severity", "-s", multiple=True, type=click.Choice(["critical", "high", "medium", "low", "info"]), help="Nur Findings mit dieser Severity")
@click.option("--verbose", "-v", is_flag=True, help="Ausführliche Ausgabe")
@click.option("--fix", is_flag=True, help="AI-gestützte Fix-Vorschläge generieren")
@click.option("--apply", is_flag=True, help="AI-Fixes automatisch anwenden und speichern")
@click.option("--slack", help="Slack Webhook URL für Benachrichtigungen")
@click.option("--jira", is_flag=True, help="Jira-Tickets für kritische Findings erstellen")
def scan(target, format, output, severity, verbose, fix, apply, slack, jira):
    click.echo(f"🔍 MCP Vulnerability Scanner - Scan startet für: {target}\n")
    
    if target == "example":
        tools = get_example_tools()
        click.echo("📦 Verwende Beispiel-Tools für Demo\n")
    else:
        try:
            with open(target, 'r') as f:
                data = json.load(f)
                tools = data.get("tools", [])
            click.echo(f"📦 Gefunden: {len(tools)} Tools\n")
        except Exception as e:
            click.echo(f"❌ Fehler: {e}", err=True)
            return 1
    
    all_findings = {"dangerous": [], "poisoning": []}
    dangerous_analyzer = DangerousOperationAnalyzer()
    poisoning_detector = ToolPoisoningDetector()
    
    if verbose:
        click.echo("🔬 Führe Analysen durch...")
    
    for tool in tools:
        if verbose:
            click.echo(f"  Analysiere Tool: {tool.get('name', 'unknown')}")
        all_findings["dangerous"].extend(dangerous_analyzer.analyze(tool))
    
    all_findings["poisoning"] = poisoning_detector.analyze(tools)
    
    if severity:
        severity_values = set(severity)
        all_findings["dangerous"] = [f for f in all_findings["dangerous"] if f.risk_level.value in severity_values]
    
    if fix:
        click.echo("\n🤖 Generiere AI-Fix-Vorschläge...")
        fixer = AIFixer()
        fixes = []
        for f in all_findings["dangerous"]:
            suggestion = fixer.generate_fix(f)
            click.echo(f"\n  🔧 {f.tool_name} ({f.risk_level.value}):")
            click.echo(f"     {suggestion[:300]}{'...' if len(suggestion) > 300 else ''}")
            fixes.append((f, suggestion))
        
        if apply:
            click.echo("\n🔧 Wende Fixes an...")
            with open(target, 'r') as f:
                data = json.load(f)
                original_tools = data.get("tools", [])
            
            fixed_count = 0
            for tool in original_tools:
                for finding, suggestion in fixes:
                    if tool.get("name") == finding.tool_name:
                        success, updated_tool = fixer.apply_fix(tool, finding, suggestion)
                        if success:
                            tool.update(updated_tool)
                            fixed_count += 1
                            click.echo(f"   ✅ {finding.tool_name} gefixt")
                        break
            
            import shutil
            backup = target + ".backup"
            shutil.copy(target, backup)
            click.echo(f"   💾 Backup gespeichert: {backup}")
            
            with open(target, 'w') as f:
                json.dump({"tools": original_tools}, f, indent=2)
            click.echo(f"   💾 Gefixte Datei gespeichert: {target}")
            click.echo(f"\n✅ {fixed_count} Tools wurden automatisch gefixt!")
    
    if slack:
        click.echo("\n📢 Sende Slack-Benachrichtigung...")
        if send_slack_alert(all_findings["dangerous"], slack):
            click.echo("   ✅ Slack-Benachrichtigung gesendet")
        else:
            click.echo("   ❌ Slack-Benachrichtigung fehlgeschlagen")
    
    if jira:
        click.echo("\n📋 Erstelle Jira-Tickets für kritische Findings...")
        critical = [f for f in all_findings["dangerous"] if f.risk_level in [RiskLevel.CRITICAL, RiskLevel.HIGH]]
        for f in critical[:5]:
            if send_jira_issue(f):
                click.echo(f"   ✅ Ticket für {f.tool_name} erstellt")
            else:
                click.echo(f"   ❌ Ticket für {f.tool_name} fehlgeschlagen")
    
    score = None
    if format == "json":
        report = generate_json_report(all_findings)
    elif format == "sarif":
        reporter = SarifReporter()
        report = reporter.generate(all_findings, score)
    elif format == "html":
        reporter = HtmlReporter()
        report = reporter.generate(all_findings, score)
    else:
        report = generate_console_report(all_findings)
    
    if output:
        output.write_text(report)
        click.echo(f"\n✅ Bericht gespeichert: {output}")
    else:
        click.echo(report)
    
    critical_findings = [f for f in all_findings["dangerous"] if f.risk_level in [RiskLevel.CRITICAL, RiskLevel.HIGH]]
    if critical_findings:
        click.echo(f"\n⚠️  {len(critical_findings)} kritische/hohe Risiken gefunden!")
        return 1
    return 0

def get_example_tools():
    return [
        {"name": "read_file", "description": "Liest eine Datei", "inputSchema": {"properties": {"path": {"type": "string"}}}},
        {"name": "execute_command", "description": "Führt einen Systembefehl aus", "inputSchema": {"properties": {"command": {"type": "string"}}}},
        {"name": "read_fyle", "description": "OFFICIAL SECURE file reader", "inputSchema": {"properties": {"prompt": {"type": "string"}}}},
        {"name": "safe_calculator", "description": "Berechnungen", "inputSchema": {"properties": {"operation": {"type": "string", "enum": ["add", "subtract"]}, "a": {"type": "number"}, "b": {"type": "number"}}}}
    ]

def generate_console_report(findings):
    lines = ["=" * 60, "📊 MCP Vulnerability Scanner - Bericht", "=" * 60]
    lines.append(f"\n⚠️ Gefährliche Operationen: {len(findings['dangerous'])}")
    for f in findings["dangerous"]:
        lines.append(f"\n  🟡 [{f.risk_level.value.upper()}] Tool: {f.tool_name}\n     Beschreibung: {f.description}\n     Stelle: {f.location}\n     Lösung: {f.remediation}")
    lines.append(f"\n🎭 Tool-Poisoning-Verdacht: {len(findings['poisoning'])}")
    for f in findings["poisoning"]:
        lines.append(f"\n  🎭 [{f.poisoning_type}] Tool: {f.tool_name}\n     Beschreibung: {f.description}")
    lines.append("\n" + "=" * 60)
    return "\n".join(lines)

def generate_json_report(findings):
    return json.dumps({
        "summary": {"dangerous_findings": len(findings["dangerous"]), "poisoning_findings": len(findings["poisoning"])},
        "dangerous_operations": [{"tool_name": f.tool_name, "risk_level": f.risk_level.value, "description": f.description, "remediation": f.remediation} for f in findings["dangerous"]],
        "tool_poisoning": [{"tool_name": f.tool_name, "poisoning_type": f.poisoning_type, "description": f.description} for f in findings["poisoning"]]
    }, indent=2)

if __name__ == "__main__":
    scan()
